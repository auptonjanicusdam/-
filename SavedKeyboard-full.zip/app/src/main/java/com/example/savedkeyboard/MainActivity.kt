package com.example.savedkeyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

class MainActivity : Activity() {

    private val data = mutableListOf<String>()
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        val pad = (16 * dp).toInt()
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        val wc = ViewGroup.LayoutParams.WRAP_CONTENT

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "۱) کیبرد رو فعال کن  ۲) هر جا تایپ می‌کنی با 🌐 یا دکمه پایین، «کیبرد ذخیره» رو انتخاب کن."
            textSize = 15f
        }, LinearLayout.LayoutParams(mp, wc))

        root.addView(Button(this).apply {
            text = "فعال‌سازی کیبرد"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "انتخاب کیبرد فعلی"
            setOnClickListener {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })

        val input = EditText(this).apply { hint = "متن جدید…"; minLines = 2 }
        root.addView(input, LinearLayout.LayoutParams(mp, wc))
        root.addView(Button(this).apply {
            text = "ذخیره"
            setOnClickListener {
                if (Store.add(this@MainActivity, input.text.toString())) {
                    input.setText("")
                    refresh()
                }
            }
        })

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, data)
        val lv = ListView(this).apply {
            this.adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, pos, _ ->
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(data[pos])
                    .setPositiveButton("حذف") { _, _ ->
                        data.removeAt(pos)
                        Store.save(this@MainActivity, data)
                        adapter.notifyDataSetChanged()
                    }
                    .setNegativeButton("بستن", null)
                    .show()
            }
        }
        root.addView(lv, LinearLayout.LayoutParams(mp, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        data.clear()
        data.addAll(Store.load(this))
        adapter.notifyDataSetChanged()
    }
}
