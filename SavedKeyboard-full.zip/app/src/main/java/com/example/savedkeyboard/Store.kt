package com.example.savedkeyboard

import android.content.Context
import org.json.JSONArray

object Store {
    private const val PREFS = "saved_texts"
    private const val KEY = "items"

    fun load(c: Context): MutableList<String> {
        val s = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val a = JSONArray(s)
        return MutableList(a.length()) { a.getString(it) }
    }

    fun save(c: Context, list: List<String>) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, JSONArray(list).toString()).apply()
    }

    fun add(c: Context, text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return false
        val l = load(c)
        if (l.contains(t)) return false
        l.add(0, t)
        save(c, l)
        return true
    }
}
