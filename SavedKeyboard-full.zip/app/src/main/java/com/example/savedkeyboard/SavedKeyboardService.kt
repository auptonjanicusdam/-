package com.example.savedkeyboard

import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.text.TextUtils
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.ExtractedTextRequest
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class SavedKeyboardService : InputMethodService() {

    private lateinit var list: LinearLayout

    override fun onCreateInputView(): View {
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1E1E1E"))
            setPadding(px(6), px(6), px(6), px(6))
        }

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 13f
            minWidth = 0
            minimumWidth = 0
            setOnClickListener { onClick() }
        }
        val lp = { LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) }

        bar.addView(btn("🌐") {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }, lp())
        bar.addView(btn("📋 ذخیره کلیپ‌بورد") { saveClipboard() }, lp().apply { weight = 3f })
        bar.addView(btn("💾 ذخیره متن فیلد") { saveField() }, lp().apply { weight = 3f })
        bar.addView(btn("⌫") { currentInputConnection?.deleteSurroundingText(1, 0) }, lp())
        bar.addView(btn("↵") { currentInputConnection?.sendDefaultEditorAction(true) }, lp())
        root.addView(bar)

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(220)))

        refresh()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (::list.isInitialized) refresh()
    }

    private fun refresh() {
        val dp = resources.displayMetrics.density
        val items = Store.load(this)
        list.removeAllViews()
        if (items.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "هنوز متنی ذخیره نشده. از دکمه‌های بالا یا از خود اپ اضافه کن."
                setTextColor(Color.LTGRAY)
                setPadding((12 * dp).toInt(), (12 * dp).toInt(), (12 * dp).toInt(), 0)
            })
            return
        }
        for (t in items) {
            val tv = TextView(this).apply {
                text = t
                maxLines = 3
                ellipsize = TextUtils.TruncateAt.END
                textSize = 16f
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.parseColor("#2C2C2C"))
                setPadding((12 * dp).toInt(), (10 * dp).toInt(), (12 * dp).toInt(), (10 * dp).toInt())
                setOnClickListener { currentInputConnection?.commitText(t, 1) }
            }
            val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            p.setMargins(0, (4 * dp).toInt(), 0, 0)
            list.addView(tv, p)
        }
    }

    private fun saveClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        done(Store.add(this, t))
    }

    private fun saveField() {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)?.toString().orEmpty()
        val t = if (selected.isNotBlank()) selected
        else ic.getExtractedText(ExtractedTextRequest(), 0)?.text?.toString().orEmpty()
        done(Store.add(this, t))
    }

    private fun done(ok: Boolean) {
        Toast.makeText(this, if (ok) "ذخیره شد" else "متنی برای ذخیره نبود یا تکراری بود", Toast.LENGTH_SHORT).show()
        if (ok) refresh()
    }
}
